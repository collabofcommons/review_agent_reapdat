from langchain_openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
import re
from langchain.chains import RetrievalQAWithSourcesChain

class VectorStoreQueryHandler:
    def __init__(self, vectorstore_dir,vectorstore_filename):

        self.vectorstore_dir = vectorstore_dir
        self.vectorstore = None
        self.embeddings = OpenAIEmbeddings()
        self.vectorstore_filename = vectorstore_filename

    def load_vectorstore(self):
        try:
            self.vectorstore = FAISS.load_local("faiss_index_dir", OpenAIEmbeddings(),
                                                allow_dangerous_deserialization=True)
            print(f"Vector store loaded successfully from {self.vectorstore_filename}.")
            # return True
            return self.vectorstore
        except Exception as e:
            print(f"An error occurred while loading the vector store: {e}")
            return False

    # chain = RetrievalQAWithSourcesChain.from_llm(llm=llm, retriever=vectorIndex.as_retriever())

    def query(self, query_text, top_k=5):
        if not self.vectorstore:
            print("Error: Vector store not loaded. Please load the vector store before querying.")
            return []

        try:
            docs_with_scores = self.vectorstore.similarity_search_with_score(query_text, k=top_k)
            return [(doc.page_content, score) for doc, score in docs_with_scores]
        except Exception as e:
            print(f"An error occurred while querying the vector store: {e}")
            return []

