# import re
# import os
# import ast
# import openai
# import json
# import numpy as np
# from langchain.chains import LLMChain
# from langchain.llms import OpenAI
# from langchain.document_loaders import CSVLoader
# from langchain.text_splitter import CharacterTextSplitter
# from langchain.vectorstores import FAISS
# from langchain.embeddings import OpenAIEmbeddings
# from langchain.prompts import PromptTemplate
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize
# from collections import Counter
# import nltk
# from nltk import pos_tag
# from string import punctuation
# from transformers import pipeline

import re
import os
import ast
import numpy as np
from langchain.chains import LLMChain
from langchain_community.llms import OpenAI
from langchain_community.document_loaders import CSVLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
# from langchain_community.embeddings import OpenAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain.prompts import PromptTemplate
from string import punctuation
from stopwordsiso import stopwords


import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.patches as patches

os.environ[
    "OPENAI_API_KEY"] = "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"


class CSVVectorStoreHandler:
    def __init__(self, csv_path):
        self.csv_path = csv_path
        self.documents = []
        self.cleaned_documents = []
        self.texts = []
        self.vectorstore = None

    def load_csv(self):
        try:
            loader = CSVLoader(self.csv_path, encoding="utf-8")
            self.documents = loader.load()
            return True
        except FileNotFoundError:
            print(f"Error: The file at '{self.csv_path}' was not found.")
        except Exception as e:
            print(f"An unexpected error occurred while loading the CSV: {e}")
        return False

    def extract_ratings(self):
        ratings = []
        try:
            for doc in self.documents:
                content = doc.page_content
                match = re.search(r"Rating:\s*Rated\s*(\d+(\.\d+)?)", content)
                if match:
                    ratings.append(float(match.group(1)))
        except Exception as e:
            print(f"Error while extracting ratings: {e}")
        return ratings

    @staticmethod
    def clean_text(text):
        """Cleans the review text by removing stopwords and punctuation."""
        stop_words = set(stopwords("en"))
        text = re.sub(f"[{re.escape(punctuation)}]", "", text)  # Remove punctuation
        words = text.lower().split()
        filtered_words = [word for word in words if word not in stop_words]
        return " ".join(filtered_words)

    def clean_documents(self):
        if not self.documents:
            print("Error: No documents loaded to clean.")
            return False

        try:
            raw_content = [doc.page_content for doc in self.documents]
            # cleaned_content = self.clean_text(raw_content)
            cleaned_content = [self.clean_text(text) for text in raw_content]
            self.cleaned_documents = [
                type(doc)(page_content=text, metadata=doc.metadata)
                for doc, text in zip(self.documents, cleaned_content)
            ]
            return True
        except Exception as e:
            print(f"An error occurred while cleaning documents: {e}")
            return False

    def split_documents(self, chunk_size=1000, chunk_overlap=0):
        if not self.cleaned_documents:
            print("Error: No cleaned documents available for splitting.")
            return False

        try:
            text_splitter = CharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
            self.texts = text_splitter.split_documents(self.cleaned_documents)
            return True
        except Exception as e:
            print(f"An error occurred while splitting documents: {e}")
            return False

    def create_vectorstore(self):
        if not self.texts:
            print("Error: No texts available for creating vector store.")
            return False

        try:
            self.vectorstore = FAISS.from_documents(self.texts, OpenAIEmbeddings())
            return True
        except Exception as e:
            print(f"An error occurred while creating the FAISS vector store: {e}")
            return False

    def save_vectorstore(self, output_dir):
        if not self.vectorstore:
            print("Error: No vector store available to save.")
            return False

        try:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            self.vectorstore.save_local(output_dir)
            print(f"Vector store saved successfully to {output_dir}.")
            return True
        except Exception as e:
            print(f"An error occurred while saving the vector store: {e}")
            return False

    @staticmethod
    def clean_review_text(text):
        """Cleans the review text by removing stopwords and punctuation."""
        stop_words = set(stopwords.words('english'))
        text = re.sub(f"[{re.escape(punctuation)}]", "", text)  # Remove punctuation
        words = word_tokenize(text.lower())
        filtered_words = [word for word in words if word not in stop_words]
        return " ".join(filtered_words)


class VectorStoreQueryHandler:
    def __init__(self, vectorstore_dir):

        self.vectorstore_dir = vectorstore_dir
        self.vectorstore = None
        self.embeddings = OpenAIEmbeddings()

    def load_vectorstore(self):
        try:
            self.vectorstore = FAISS.load_local(self.vectorstore_dir, OpenAIEmbeddings(),
                                                allow_dangerous_deserialization=True)
            print(f"Vector store loaded successfully from {self.vectorstore_dir}.")
            return True
        except Exception as e:
            print(f"An error occurred while loading the vector store: {e}")
            return False

    def query(self, query_text, top_k=5):
        if not self.vectorstore:
            print("Error: Vector store not loaded. Please load the vector store before querying.")
            return []

        try:
            docs_with_scores = self.vectorstore.similarity_search_with_score(query_text, k=top_k)
            return [(doc.page_content, score) for doc, score in docs_with_scores]
        except Exception as e:
            print(f"An error occurred while querying the vector store: {e}")
            return []

    def analyze_rating(self, rating):
        if rating > 3:
            return "positive"
        elif rating == 3:
            return "neutral"
        else:
            return "negative"

    def calculate_ratings_percentages(self, ratings):
        """
        Calculates the percentage of positive, negative, and neutral ratings.

        Args:
            ratings (list of int): A list of numerical ratings (e.g., 1-5).

        Returns:
            str: A string displaying the percentage of positive, negative, and neutral ratings.
        """
        try:
            # Analyze sentiments
            sentiments = [self.analyze_rating(rating) for rating in ratings]

            # Calculate counts
            total_ratings = len(ratings)
            positive_count = sentiments.count("positive")
            neutral_count = sentiments.count("neutral")
            negative_count = sentiments.count("negative")

            # Calculate percentages
            positive_percentage = round((positive_count / total_ratings) * 100)
            neutral_percentage = round((neutral_count / total_ratings) * 100)
            negative_percentage = round((negative_count / total_ratings) * 100)

            # Format output
            result = (
                f"positive - {positive_percentage:}%, "
                f"neutral - {neutral_percentage:}%, "
                f"negative - {negative_percentage:}%"
            )

            return result
        except Exception as e:
            return f"An error occurred while calculating percentages: {e}"

    def analyze_sentiment(self, review):
        try:
            # Initialize the OpenAI LLM
            llm = OpenAI()
            prompt = PromptTemplate(input_variables=["review"],
                                    template="Analyze the sentiment of this review: {review}")
            chain = LLMChain(llm=llm, prompt=prompt)
            sentiment = chain.run({"review": review})

            # Return the sentiment based on the output
            if "positive" in sentiment.lower():
                return "Positive"
            elif "negative" in sentiment.lower():
                return "Negative"
            elif "neutral" in sentiment.lower():
                return "Neutral"
            else:
                return "Error"
        except Exception as e:
            print(f"An error occurred while analyzing sentiment: {e}")
            return "Error"

    def fetch_top_topics(self, reviews, sentiment, top_n=10):
        try:
            llm = OpenAI()
            prompt = PromptTemplate(
                input_variables=["reviews", "sentiment"],
                template="From these reviews: {reviews}, extract the top {top_n} {sentiment} topics, each 5-6 words long."
            )
            chain = LLMChain(llm=llm, prompt=prompt)
            topics = chain.run({"reviews": reviews, "sentiment": sentiment, "top_n": top_n})

            # Ensure topics are split into a list
            if isinstance(topics, str):
                topics = [topic.strip() for topic in topics.split('\n') if topic.strip()]

            # Calculate semantic matches for each topic in reviews
            from sentence_transformers import SentenceTransformer, util
            model = SentenceTransformer('all-MiniLM-L6-v2')

            review_embeddings = model.encode(reviews, convert_to_tensor=True)
            topic_embeddings = model.encode(topics, convert_to_tensor=True)

            topic_scores = {}
            for topic, topic_embedding in zip(topics, topic_embeddings):
                scores = util.cos_sim(topic_embedding, review_embeddings)
                topic_scores[topic] = scores.mean().item() * 100  # Convert to percentage

            # Format the output as required
            formatted_output = "\n".join([
                f"{topic} - {score:.2f}%" for topic, score in topic_scores.items()
            ])

            return formatted_output
        except Exception as e:
            print(f"An error occurred while fetching topics: {e}")
            return "Error"

    def summarize_reviews(self, reviews):
        try:
            # Initialize the LLM
            llm = OpenAI()

            # Define the prompt template
            prompt = PromptTemplate(
                input_variables=["reviews"],
                template=(
                    "Summarize the following customer reviews into 3-4 concise sentences:\n\n"
                    "{reviews}\n\n"
                    "Provide a clear and comprehensive summary."
                ),
            )

            # Create the chain
            chain = LLMChain(llm=llm, prompt=prompt)

            # Combine reviews into a single text
            combined_reviews = " ".join(reviews)

            # Run the chain to get the summary
            summary = chain.run({"reviews": combined_reviews})

            return summary.strip()
        except Exception as e:
            return f"An error occurred while summarizing reviews: {e}"

    def calculate_review_sentiment_percentage(self, reviews):
        try:
            # Step 1: Initialize counters for sentiments
            sentiment_counts = {"Positive": 0, "Negative": 0, "Neutral": 0}

            # Step 2: Classify sentiments for each review and count them
            for review in reviews:
                sentiment = self.analyze_sentiment(review)
                if sentiment == "Positive":
                    sentiment_counts["Positive"] += 1
                elif sentiment == "Negative":
                    sentiment_counts["Negative"] += 1
                elif sentiment == "Neutral":
                    sentiment_counts["Neutral"] += 1

            # Step 3: Calculate percentages
            total_reviews = len(reviews)
            if total_reviews == 0:
                return "No reviews to analyze"

            positive_percentage = round((sentiment_counts["Positive"] / total_reviews) * 100)
            negative_percentage = round((sentiment_counts["Negative"] / total_reviews) * 100)
            neutral_percentage = round((sentiment_counts["Neutral"] / total_reviews) * 100)

            # Return the sentiment percentages
            return f"Positive - {positive_percentage}%, Negative - {negative_percentage}%, Neutral - {neutral_percentage}%"

        except Exception as e:
            print(f"An error occurred while calculating sentiment percentages: {e}")
            return "Error"

    # Function to format data into input text
    def format_input_data(self, ratings_percentage, sentiment_percentage, positive_topics, negative_topics, summary):
        """
        Converts structured data into a text format suitable for LLM input.
        """

        input_text = (
            f"ratings_percentage = {ratings_percentage}\n"
            f"sentiment_percentage = {sentiment_percentage}\n"
            f"positive_topics = {positive_topics}\n"
            f"negative_topics = {negative_topics}\n"
            f"summary - {summary}"
        )
        return input_text

    def parse_data_and_create_charts(self, input_text):
        # Extract data sections from input text
        ratings_section = input_text.split("ratings_percentage =")[1].split("sentiment_percentage =")[0].strip()
        sentiment_section = input_text.split("sentiment_percentage =")[1].split("positive_topics =")[0].strip()
        positive_topics_section = input_text.split("positive_topics =")[1].split("negative_topics =")[0].strip()
        negative_topics_section = input_text.split("negative_topics =")[1].split("summary -")[0].strip()
        summary_section = input_text.split("summary -")[1].strip()

        # Parse ratings
        ratings = {}
        for item in ratings_section.split(","):
            key, value = item.strip().split("-")
            ratings[key.strip()] = float(value.strip().replace('%', ''))

        # Parse sentiment
        sentiment = {}
        for item in sentiment_section.split(","):
            key, value = item.strip().split("-")
            sentiment[key.strip()] = float(value.strip().replace('%', ''))

        # Parse positive topics
        positive_topics = {}
        for line in positive_topics_section.split("\n"):
            try:
                key, value = line.split("-", maxsplit=1)  # Split only at the first dash
                topic_name = key.split(".")[1].strip()  # Extract the topic name after the number
                percentage = float(value.strip().replace('%', ''))
                positive_topics[topic_name] = percentage
            except ValueError:
                print(f"Skipping line in positive_topics: {line}")

        # Parse negative topics
        negative_topics = {}
        for line in negative_topics_section.split("\n"):
            try:
                key, value = line.split("-", maxsplit=1)  # Split only at the first dash
                topic_name = key.split(".")[1].strip()  # Extract the topic name after the number
                percentage = float(value.strip().replace('%', ''))
                negative_topics[topic_name] = percentage
            except ValueError:
                print(f"Skipping line in negative_topics: {line}")

        # Plot charts
        plt.figure(figsize=(15, 12))

        # Add the summary as a title
        plt.suptitle(f"Summary: {summary_section}", fontsize=12, y=0.95, wrap=True)

        # Ratings Pie Chart
        plt.subplot(2, 2, 1)
        plt.pie(ratings.values(), labels=ratings.keys(), autopct='%1.1f%%', colors=['lightgreen', 'gold', 'salmon'])
        plt.title("Ratings Percentage")

        # Sentiment Pie Chart
        plt.subplot(2, 2, 2)
        plt.pie(sentiment.values(), labels=sentiment.keys(), autopct='%1.1f%%', colors=['lightblue', 'red', 'orange'])
        plt.title("Sentiment Percentage")

        # Positive Topics Bar Chart
        plt.subplot(2, 2, 3)
        plt.barh(list(positive_topics.keys()), list(positive_topics.values()), color='green')
        plt.xlabel("Percentage")
        plt.ylabel("Positive Topics")
        plt.title("Positive Topics Breakdown")

        # Negative Topics Bar Chart
        plt.subplot(2, 2, 4)
        plt.barh(list(negative_topics.keys()), list(negative_topics.values()), color='red')
        plt.xlabel("Percentage")
        plt.ylabel("Negative Topics")
        plt.title("Negative Topics Breakdown")

        # Adjust layout
        plt.tight_layout(rect=[0, 0, 1, 0.92])  # Leave space for the summary title
        plt.show()


if __name__ == "__main__":
    csv_path = "C:/Users/Mani_Moon/reapdat/input_files/madrasrest/madrasrest_reviews_sample.csv"
    # Replace with your CSV file path
    output_file = "C:/Users/Mani_Moon/reapdat/vectorestore/output/output.jpg"
    handler = CSVVectorStoreHandler(csv_path)

    if handler.load_csv():
        print("CSV loaded successfully.")

        if handler.clean_documents():
            print("Documents cleaned successfully.")

            if handler.split_documents():
                print("Documents split successfully.")

                if handler.create_vectorstore():
                    print("Vector store created successfully.")

                    output_dir = "C:/Users/Mani_Moon/reapdat/vectorestore/output"  # Replace with your output directory
                    if handler.save_vectorstore(output_dir):

                        query_handler = VectorStoreQueryHandler(output_dir)
                        if query_handler.load_vectorstore():
                            ratings = handler.extract_ratings()
                            # print(f"Ratings: {ratings}")

                            # print(f"Rating: {rating} -> {query_handler.analyze_rating(rating)}")

                            ratings_percentage = query_handler.calculate_ratings_percentages(ratings)
                            print("ratings_percentage:", ratings_percentage)

                            reviews = [doc.page_content for doc in handler.documents]

                            sentiment_percentage = query_handler.calculate_review_sentiment_percentage(reviews)
                            print("sentiment_percentage:", sentiment_percentage)

                            positive_topics = query_handler.fetch_top_topics(reviews, "positive")
                            print("positive_topics:", positive_topics)

                            negative_topics = query_handler.fetch_top_topics(reviews, "negative")
                            print("negative_topics:", negative_topics)

                            summary = query_handler.summarize_reviews(reviews)
                            print("summary:", summary)

                            # Format the input data
                            input_text = query_handler.format_input_data(ratings_percentage, sentiment_percentage,
                                                                         positive_topics, negative_topics, summary)

                            query_handler.parse_data_and_create_charts(input_text)
