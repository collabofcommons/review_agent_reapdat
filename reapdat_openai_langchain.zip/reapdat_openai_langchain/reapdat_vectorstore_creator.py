import faiss
from langchain.vectorstores import FAISS
from langchain.embeddings.openai import OpenAIEmbeddings

class VectorStoreCreator:
    def __init__(self, texts,vectorstore_dir,vectorstore_filename):
        self.texts = texts
        self.vectorstore_dir = vectorstore_dir
        self.vectorstore_filename = vectorstore_filename
        self.vectorstore = None

    def create_vectorstore(self):
        if not self.texts:
            print("Error: No texts available for creating vector store.")
            return False

        try:
            embeddings = OpenAIEmbeddings()
            self.vectorstore = FAISS.from_documents(self.texts, embeddings)
            print("Embedding Vector Started Building...✅✅✅")

            # Save the FAISS index to a file
            self.vectorstore.save_local("faiss_index_dir")
            print("FAISS vector store saved successfully.")
            return True

        except Exception as e:
            print(f"An error occurred while creating the FAISS vector store: {e}")
            return False


