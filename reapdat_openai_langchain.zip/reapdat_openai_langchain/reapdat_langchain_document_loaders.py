from langchain_community.document_loaders import *
from string import punctuation
from stopwordsiso import stopwords
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

from reapdat_vectorstore_creator import VectorStoreCreator

import pickle
import re
import time

file_path = "faiss_store_openai.pkl"

class CSVVectorStoreHandler:
    def __init__(self, csv_path,vectorstore_dir,vectorstore_filename):
        self.csv_path = csv_path
        self.documents = []
        self.cleaned_documents = []
        self.texts = []
        self.vectorstore = None
        self.vectorstore_dir = vectorstore_dir
        self.vectorstore_filename = vectorstore_filename

    def load_csv(self):
        try:
            loader = CSVLoader(self.csv_path, encoding="utf-8")
            self.documents = loader.load()
            return True
        except FileNotFoundError:
            print(f"Error: The file at '{self.csv_path}' was not found.")
        except Exception as e:
            print(f"An unexpected error occurred while loading the CSV: {e}")
        return False

    @staticmethod
    def clean_text(text):
        """Cleans the review text by removing stopwords and punctuation."""
        stop_words = set(stopwords("en"))
        text = re.sub(f"[{re.escape(punctuation)}]", "", text)  # Remove punctuation
        words = text.lower().split()
        filtered_words = [word for word in words if word not in stop_words]
        return " ".join(filtered_words)

    def clean_documents(self):
        if not self.documents:
            print("Error: No documents loaded to clean.")
            return False

        try:
            raw_content = [doc.page_content for doc in self.documents]
            # cleaned_content = self.clean_text(raw_content)
            cleaned_content = [self.clean_text(text) for text in raw_content]
            self.cleaned_documents = [
                type(doc)(page_content=text, metadata=doc.metadata)
                for doc, text in zip(self.documents, cleaned_content)
            ]
            return True
        except Exception as e:
            print(f"An error occurred while cleaning documents: {e}")
            return False

    def split_documents(self, chunk_size=1000, chunk_overlap=0):
        if not self.cleaned_documents:
            print("Error: No cleaned documents available for splitting.")
            return False

        try:

            text_splitter = RecursiveCharacterTextSplitter(
                                separators=['\n\n', '\n', '.', ','],
                                chunk_size=1000
                            )
            print("Text Splitter...Started...✅✅✅")

            self.texts = text_splitter.split_documents(self.cleaned_documents)
            print("the length of the documents:",len(self.texts))
            print(self.texts[0])
            # for chunks in self.texts:
            #     print(chunks)
            # text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
            # self.texts = text_splitter.split_documents(self.cleaned_documents)
            return True
        except Exception as e:
            print(f"An error occurred while splitting documents: {e}")
            return False

    def extract_ratings(self):
        ratings = []
        try:
            for doc in self.documents:
                content = doc.page_content
                match = re.search(r"Rating:\s*Rated\s*(\d+(\.\d+)?)", content)
                if match:
                    ratings.append(float(match.group(1)))
        except Exception as e:
            print(f"Error while extracting ratings: {e}")
        return ratings

    def analyze_rating(self, rating):
        if rating > 3:
            return "positive"
        elif rating == 3:
            return "neutral"
        else:
            return "negative"

    def calculate_ratings_percentages(self, ratings):
        """
        Calculates the percentage of positive, negative, and neutral ratings.

        Args:
            ratings (list of int): A list of numerical ratings (e.g., 1-5).

        Returns:
            str: A string displaying the percentage of positive, negative, and neutral ratings.
        """
        try:
            # Analyze sentiments
            sentiments = [self.analyze_rating(rating) for rating in ratings]

            # Calculate counts
            total_ratings = len(ratings)
            positive_count = sentiments.count("positive")
            neutral_count = sentiments.count("neutral")
            negative_count = sentiments.count("negative")

            # Calculate percentages
            positive_percentage = round((positive_count / total_ratings) * 100)
            neutral_percentage = round((neutral_count / total_ratings) * 100)
            negative_percentage = round((negative_count / total_ratings) * 100)

            # Format output
            result = (
                f"positive - {positive_percentage:}%, "
                f"neutral - {neutral_percentage:}%, "
                f"negative - {negative_percentage:}%"
            )

            return result
        except Exception as e:
            return f"An error occurred while calculating percentages: {e}"

    def create_vectorstore_from_main(self):
        if not self.texts:
            print("Error: No texts available for creating vector store.")
            return False

        vector_handler = VectorStoreCreator(self.texts,self.vectorstore_dir,self.vectorstore_filename)
        if vector_handler.create_vectorstore():
            print("Vector store created successfully.")



