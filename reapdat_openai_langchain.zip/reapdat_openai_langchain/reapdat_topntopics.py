import re
import os
import ast
import numpy as np
from langchain.chains import LLMChain
from langchain_community.llms import OpenAI
from langchain_community.document_loaders import CSVLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain_community.vectorstores import FAISS
# from langchain_community.embeddings import OpenAIEmbeddings
from langchain_openai import OpenAIEmbeddings
from langchain.prompts import PromptTemplate
from string import punctuation
from stopwordsiso import stopwords

## pip install faiss-cpu, pip install langchain-openai

os.environ[
    "OPENAI_API_KEY"] = "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"


class CSVVectorStoreHandler:
    def __init__(self, csv_path):
        self.csv_path = csv_path
        self.documents = []
        self.cleaned_documents = []
        self.texts = []
        self.vectorstore = None

    def load_csv(self):
        try:
            loader = CSVLoader(self.csv_path, encoding="utf-8")
            self.documents = loader.load()
            return True
        except FileNotFoundError:
            print(f"Error: The file at '{self.csv_path}' was not found.")
        except Exception as e:
            print(f"An unexpected error occurred while loading the CSV: {e}")
        return False

    def extract_ratings(self):
        ratings = []
        try:
            for doc in self.documents:
                content = doc.page_content
                match = re.search(r"Rating:\s*Rated\s*(\d+(\.\d+)?)", content)
                if match:
                    ratings.append(float(match.group(1)))
        except Exception as e:
            print(f"Error while extracting ratings: {e}")
        return ratings

    @staticmethod
    def clean_text(text):
        """Cleans the review text by removing stopwords and punctuation."""
        stop_words = set(stopwords("en"))
        text = re.sub(f"[{re.escape(punctuation)}]", "", text)  # Remove punctuation
        words = text.lower().split()
        filtered_words = [word for word in words if word not in stop_words]
        return " ".join(filtered_words)

    def clean_documents(self):
        if not self.documents:
            print("Error: No documents loaded to clean.")
            return False

        try:
            raw_content = [doc.page_content for doc in self.documents]
            # cleaned_content = self.clean_text(raw_content)
            cleaned_content = [self.clean_text(text) for text in raw_content]
            self.cleaned_documents = [
                type(doc)(page_content=text, metadata=doc.metadata)
                for doc, text in zip(self.documents, cleaned_content)
            ]
            return True
        except Exception as e:
            print(f"An error occurred while cleaning documents: {e}")
            return False

    def split_documents(self, chunk_size=1000, chunk_overlap=0):
        if not self.cleaned_documents:
            print("Error: No cleaned documents available for splitting.")
            return False

        try:
            text_splitter = CharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
            self.texts = text_splitter.split_documents(self.cleaned_documents)
            return True
        except Exception as e:
            print(f"An error occurred while splitting documents: {e}")
            return False

    def create_vectorstore(self):
        if not self.texts:
            print("Error: No texts available for creating vector store.")
            return False

        try:
            self.vectorstore = FAISS.from_documents(self.texts, OpenAIEmbeddings())
            return True
        except Exception as e:
            print(f"An error occurred while creating the FAISS vector store: {e}")
            return False

    def save_vectorstore(self, output_dir):
        if not self.vectorstore:
            print("Error: No vector store available to save.")
            return False

        try:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            self.vectorstore.save_local(output_dir)
            print(f"Vector store saved successfully to {output_dir}.")
            return True
        except Exception as e:
            print(f"An error occurred while saving the vector store: {e}")
            return False

    @staticmethod
    def clean_review_text(text):
        """Cleans the review text by removing stopwords and punctuation."""
        stop_words = set(stopwords.words('english'))
        text = re.sub(f"[{re.escape(punctuation)}]", "", text)  # Remove punctuation
        words = word_tokenize(text.lower())
        filtered_words = [word for word in words if word not in stop_words]
        return " ".join(filtered_words)


class VectorStoreQueryHandler:
    def __init__(self, vectorstore_dir):
        self.vectorstore_dir = vectorstore_dir
        self.vectorstore = None
        self.embeddings = OpenAIEmbeddings()

    def load_vectorstore(self):
        try:
            self.vectorstore = FAISS.load_local(self.vectorstore_dir, OpenAIEmbeddings(),
                                                allow_dangerous_deserialization=True)
            print(f"Vector store loaded successfully from {self.vectorstore_dir}.")
            return True
        except Exception as e:
            print(f"An error occurred while loading the vector store: {e}")
            return False

    def truncate_text(self, text, max_tokens=3000):
        """
        Truncate the text to ensure it fits within the model's token limit.
        """
        words = text.split()
        if len(words) > max_tokens:
            return " ".join(words[:max_tokens])
        return text

    def query(self, query_text, top_k=5):
        if not self.vectorstore:
            print("Error: Vector store not loaded. Please load the vector store before querying.")
            return []

        try:
            # Truncate the query text
            truncated_query = self.truncate_text(query_text)

            docs_with_scores = self.vectorstore.similarity_search_with_score(truncated_query, k=top_k)
            return [(doc.page_content, score) for doc, score in docs_with_scores]
        except Exception as e:
            print(f"An error occurred while querying the vector store: {e}")
            return []

    def analyze_sentiment(self, review):
        try:
            # Truncate the review to fit token limits
            truncated_review = self.truncate_text(review)

            # Initialize the OpenAI LLM
            llm = OpenAI(max_tokens=100)  # Limit output token length
            prompt = PromptTemplate(input_variables=["review"],
                                    template="Analyze the sentiment of this review: {review}")
            chain = LLMChain(llm=llm, prompt=prompt)
            sentiment = chain.run({"review": truncated_review})

            # Return the sentiment based on the output
            if "positive" in sentiment.lower():
                return "Positive"
            elif "negative" in sentiment.lower():
                return "Negative"
            elif "neutral" in sentiment.lower():
                return "Neutral"
            else:
                return "Error"
        except Exception as e:
            print(f"An error occurred while analyzing sentiment: {e}")
            return "Error"

    def fetch_top_topics(self, reviews, sentiment, top_n=10):
        try:
            # Combine reviews into a single text
            combined_reviews = " ".join(reviews)

            # Truncate combined reviews
            truncated_reviews = self.truncate_text(combined_reviews, max_tokens=3000)

            llm = OpenAI(max_tokens=150)  # Limit output token length
            prompt = PromptTemplate(
                input_variables=["reviews", "sentiment"],
                template="From these reviews: {reviews}, extract the top {top_n} {sentiment} topics, each 5-6 words long."
            )
            chain = LLMChain(llm=llm, prompt=prompt)
            topics = chain.run({"reviews": truncated_reviews, "sentiment": sentiment, "top_n": top_n})

            # Ensure topics are split into a list
            if isinstance(topics, str):
                topics = [topic.strip() for topic in topics.split('\n') if topic.strip()]

            # Calculate semantic matches for each topic in reviews
            from sentence_transformers import SentenceTransformer, util
            model = SentenceTransformer('all-MiniLM-L6-v2')

            review_embeddings = model.encode(reviews, convert_to_tensor=True)
            topic_embeddings = model.encode(topics, convert_to_tensor=True)

            topic_scores = {}
            for topic, topic_embedding in zip(topics, topic_embeddings):
                scores = util.cos_sim(topic_embedding, review_embeddings)
                topic_scores[topic] = scores.mean().item() * 100  # Convert to percentage

            # Format the output as required
            formatted_output = "\n".join([
                f"{topic} - {score:.2f}%" for topic, score in topic_scores.items()
            ])

            return formatted_output
        except Exception as e:
            print(f"An error occurred while fetching topics: {e}")
            return "Error"

    def summarize_reviews(self, reviews):
        try:
            # Truncate reviews if too large
            combined_reviews = " ".join(reviews)
            truncated_reviews = self.truncate_text(combined_reviews, max_tokens=3000)

            # Initialize the LLM
            llm = OpenAI(max_tokens=150)  # Limit output token length

            # Define the prompt template
            prompt = PromptTemplate(
                input_variables=["reviews"],
                template=(
                    "Summarize the following customer reviews into 3-4 concise sentences:\n\n"
                    "{reviews}\n\n"
                    "Provide a clear and comprehensive summary."
                ),
            )

            # Create the chain
            chain = LLMChain(llm=llm, prompt=prompt)

            # Run the chain to get the summary
            summary = chain.run({"reviews": truncated_reviews})

            return summary.strip()
        except Exception as e:
            return f"An error occurred while summarizing reviews: {e}"

    def calculate_review_sentiment_percentage(self, reviews):
        try:
            # Step 1: Initialize counters for sentiments
            sentiment_counts = {"Positive": 0, "Negative": 0, "Neutral": 0}

            # Process reviews in batches if necessary
            batch_size = 50  # Adjust batch size based on API limits
            for i in range(0, len(reviews), batch_size):
                batch = reviews[i:i + batch_size]
                for review in batch:
                    sentiment = self.analyze_sentiment(review)
                    if sentiment == "Positive":
                        sentiment_counts["Positive"] += 1
                    elif sentiment == "Negative":
                        sentiment_counts["Negative"] += 1
                    elif sentiment == "Neutral":
                        sentiment_counts["Neutral"] += 1

            # Step 3: Calculate percentages
            total_reviews = len(reviews)
            if total_reviews == 0:
                return "No reviews to analyze"

            positive_percentage = round((sentiment_counts["Positive"] / total_reviews) * 100)
            negative_percentage = round((sentiment_counts["Negative"] / total_reviews) * 100)
            neutral_percentage = round((sentiment_counts["Neutral"] / total_reviews) * 100)

            # Return the sentiment percentages
            return f"Positive - {positive_percentage}%, Negative - {negative_percentage}%, Neutral - {neutral_percentage}%"

        except Exception as e:
            print(f"An error occurred while calculating sentiment percentages: {e}")
            return "Error"

    if __name__ == "__main__":
        csv_path = "C:/Users/Mani_Moon/reapdat/input_files/madrasrest/madrasrest_reviews.csv"  # Replace with your CSV file path
        handler = CSVVectorStoreHandler(csv_path)

        if handler.load_csv():
            print("CSV loaded successfully.")

            if handler.clean_documents():
                print("Documents cleaned successfully.")

                if handler.split_documents():
                    print("Documents split successfully.")

                    if handler.create_vectorstore():
                        output_dir = "C:/Users/Mani_Moon/reapdat/vectorestore/output"  # Replace with your output directory
                        print("Vector store created successfully.")
                        if handler.save_vectorstore(output_dir):
                            print("Hello")

                            query_handler = VectorStoreQueryHandler(output_dir)
        #                 if query_handler.load_vectorstore():
        #                     ratings = handler.extract_ratings()
        #                     print("Ratings created successfully.")
        #
        #                     # print(f"Rating: {rating} -> {query_handler.analyze_rating(rating)}")
        #
        #                     ratings_percentage = query_handler.calculate_ratings_percentages(ratings)
        #
        #                     reviews = [doc.page_content for doc in handler.documents]
        #
        #                     sentiment_percentage = query_handler.calculate_review_sentiment_percentage(reviews)
        #
        #                     positive_topics = query_handler.fetch_top_topics(reviews, "positive")
        #                     print("fetch_top_topics:", positive_topics)
        #
        #                     negative_topics = query_handler.fetch_top_topics(reviews, "negative")
        #                     print("fetch_top_topics:", negative_topics)
        #
        #                     summary = query_handler.summarize_reviews(reviews)
