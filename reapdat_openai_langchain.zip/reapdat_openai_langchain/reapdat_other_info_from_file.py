import re

class OtherInfoFromFile:
    def __init__(self, documents):
        self.documents = documents

